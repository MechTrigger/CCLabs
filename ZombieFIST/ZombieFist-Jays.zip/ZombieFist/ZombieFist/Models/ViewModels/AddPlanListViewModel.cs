﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZombieFist.Models.ViewModels
{
    public class AddPlanListViewModel
    {
        public string Name { get; set; }
    }
}
