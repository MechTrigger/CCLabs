﻿

namespace ZombieFist.Models.ViewModels
{
    public class AddPlanListItemViewModel
    {
        public int ListId { get; set; }
        public string Text { get; set; }
    }
}
