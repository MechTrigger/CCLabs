﻿using Microsoft.AspNet.Identity.EntityFramework;
using ZombieFist.Models.DomainModels;

namespace ZombieFist.Models.Data
{     
    // NOTE: Used to be in Models/IdentityModels.cs, easier to 
    // find/use if it is in it's own file.
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
            this.Configuration.ProxyCreationEnabled = false;
            this.Configuration.LazyLoadingEnabled = true;
        }
        
        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }
    }
}