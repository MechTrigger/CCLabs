﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using ZombieFist.Models.DomainModels;

namespace ZombieFist.Models.Repositories.Implementations
{
    // GenericRepository talks to db-context to keep unbroken chain to server
    // We Implemented the IPlanListRepository 
    public class PlanListRepository : GenericRepository,  IPlanListRepository
    {   
        public PlanList Get(string userId, int id)
        {
			var listToGet = this.Query<PlanList>()
								.Include(list => list.Items)
								.Where(list => list.User.Id == userId)
								.Where(list => list.Id == id)
								.FirstOrDefault();

	        if (listToGet.User.Id != userId)
		        return null;

	        return listToGet;
        }

        public IList<PlanList> GetAll(string userId)
        {
            return this.Query<PlanList>()
                       .Include(list => list.Items)
                       .Where(list => list.User.Id == userId)
                       .ToList();
        }

        public void AddList(string userId, string name)
        {
            var user = CurrentUser(userId);
            var plan = new PlanList() { Name = name };
            user.Lists.Add(plan);
        }

        public void DeleteList(string userId, int id)
        {
	        var listToDelete = this.Query<PlanList>()
								   .Include(list => list.Items)
								   .Where(list => list.User.Id == userId)
								   .Where(list => list.Id == id)
								   .FirstOrDefault();

			var items = listToDelete.Items.ToList();
			for (var i = 0; i < items.Count; i++)
				this.Delete(items[i]);

            this.Delete<PlanList>(id);
        }

		public void AddItem(string userId, int listId, string text)
        {
			var listToAddItemTo = this.Query<PlanList>()
								      .Include(list => list.Items)
								      .Where(list => list.User.Id == userId)
								      .Where(list => list.Id == listId)
								      .FirstOrDefault();
			if (listToAddItemTo != null)
			{
				var item = new PlanListItem() { Text = text };
				listToAddItemTo.Items.Add(item);
			}
        }

		public void DeleteItem(string userId, int itemId)
		{
			var itemToDelete = this.Query<PlanListItem>()
								   .Include(list => list.PlanList)
								   .Include(p => p.PlanList.User)
								   .Where(item => item.Id == itemId)
								   .FirstOrDefault();


			if (itemToDelete.PlanList.User.Id == userId)
				this.Delete<PlanListItem>(itemId);
        }
    }
}
