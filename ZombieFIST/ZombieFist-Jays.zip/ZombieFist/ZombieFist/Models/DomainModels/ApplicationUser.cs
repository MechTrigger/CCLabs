﻿using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace ZombieFist.Models.DomainModels
{
    // Since Users are Domain Models, they were put with the other DM's. 
    // Part of EF Identity previously named "IdentityModels.cs"
    // Renamed to ApplicationUser to be consistent w/coding standards 
    public class ApplicationUser : IdentityUser
    {
        // Adding ICollection<PLanList> as a property tells the server we want to associate 
        // lists with Users. 
        public string FirstName { get; set; }
        public string LastName { get; set; }       
        public ICollection<PlanList> Lists { get; set; } 

        // Constructor for User is creating a new PlanList for this user at the same time. 
        public ApplicationUser()
        {
            this.Lists = new List<PlanList>();
        }

        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager, string authenticationType)
        {
            var userIdentity = await manager.CreateIdentityAsync(this, authenticationType);
            // Add custom user claims here
            return userIdentity;
        }
    }

}