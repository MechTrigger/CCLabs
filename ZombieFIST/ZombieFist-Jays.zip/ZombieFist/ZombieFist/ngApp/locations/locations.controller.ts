﻿namespace zombieApp.locations {


    class locationsController {
        static $inject: string[] = ['planLocationService', 'identityService'];


        constructor(private planLocationService: IPlanLocationService, private identityService: identity.identityService) {

            // these lines get the profile for the currently logged in user,
            // and if they are not logged in, we redirect them back to the login page
            var user = this.identityService.getProfile();
            if (!user.isAuthenticated) {
                this.identityService.logout();
            }

            this.load();
        }


        private load() {
        }
    }

    angular.module('zombieApp').controller('locationsController', locationsController);
}