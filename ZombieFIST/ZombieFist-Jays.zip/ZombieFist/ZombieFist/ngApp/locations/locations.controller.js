var zombieApp;
(function (zombieApp) {
    var locations;
    (function (locations) {
        var locationsController = (function () {
            function locationsController(planLocationService, identityService) {
                this.planLocationService = planLocationService;
                this.identityService = identityService;
                // these lines get the profile for the currently logged in user,
                // and if they are not logged in, we redirect them back to the login page
                var user = this.identityService.getProfile();
                if (!user.isAuthenticated) {
                    this.identityService.logout();
                }
                this.load();
            }
            locationsController.prototype.load = function () {
            };
            locationsController.$inject = ['planLocationService', 'identityService'];
            return locationsController;
        })();
        angular.module('zombieApp').controller('locationsController', locationsController);
    })(locations = zombieApp.locations || (zombieApp.locations = {}));
})(zombieApp || (zombieApp = {}));
