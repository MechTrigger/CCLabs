﻿//  moved identity logic from controller to service
namespace zombieApp.locations {
    'use strict';


    export interface IPlanLocationService {
    }


    export class planLocationService implements IPlanLocationService {
        static $inject: string[] = ['$http'];


        constructor(private $http: ng.IHttpService) {
        }

    }

    angular.module('zombieApp').service('planLocationService', planLocationService);
}