//  moved identity logic from controller to service
var zombieApp;
(function (zombieApp) {
    var locations;
    (function (locations) {
        'use strict';
        var planLocationService = (function () {
            function planLocationService($http) {
                this.$http = $http;
            }
            planLocationService.$inject = ['$http'];
            return planLocationService;
        })();
        locations.planLocationService = planLocationService;
        angular.module('zombieApp').service('planLocationService', planLocationService);
    })(locations = zombieApp.locations || (zombieApp.locations = {}));
})(zombieApp || (zombieApp = {}));
