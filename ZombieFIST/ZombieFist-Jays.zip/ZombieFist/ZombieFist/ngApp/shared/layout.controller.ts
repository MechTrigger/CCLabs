﻿namespace zombieApp {

    // controller that all the views have access to. 
    class layoutController {
        static $inject: string[] = ['$scope', 'identityService', '$location', '$window'];

        constructor(private $scope: ng.IScope, private identityService: identity.identityService, private $location: ng.ILocationService, private $window: ng.IWindowService) {

            this.user = this.identityService.getProfile();
            this.navIsCollapsed = true;

            this.$scope.$watch(
                () => $window.sessionStorage.getItem('profile'),
                (value) => this.user = JSON.parse(value)
            );
        }


        user: identity.userProfileViewModel;
        navIsCollapsed: boolean;

        // CUSTOM ANGULAR METHOD // 
        // USED IN: Main navigation in layouts (Views/Home/index.cshtml, /other, /other)
        // Bootstrap adds a class named "active" to <li> tags. We use this "active" class status
        // from Bootstrap to show the user a different style on the link/menu item they are on (active-state look). 
        // HOW:  
        isActiveView(path: string): string {
            path = path.toLowerCase();
            var currentPath = this.$location.path().toLowerCase();
            return currentPath.indexOf(path) >= 0 ? 'active' : '';
        }

        logout(): void {
            this.identityService.logout();
        }
    }

    angular.module('zombieApp').controller('layoutController', layoutController);
}