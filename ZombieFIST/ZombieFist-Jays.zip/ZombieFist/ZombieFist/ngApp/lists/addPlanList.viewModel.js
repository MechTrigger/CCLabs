var zombieApp;
(function (zombieApp) {
    var lists;
    (function (lists) {
        // Typescript class that matches up with the C# class used by Web Api
        var addPlanListViewModel = (function () {
            function addPlanListViewModel() {
            }
            return addPlanListViewModel;
        })();
        lists.addPlanListViewModel = addPlanListViewModel;
    })(lists = zombieApp.lists || (zombieApp.lists = {}));
})(zombieApp || (zombieApp = {}));
