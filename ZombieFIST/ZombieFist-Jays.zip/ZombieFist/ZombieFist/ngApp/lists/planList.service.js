//  moved identity logic from controller to service
var zombieApp;
(function (zombieApp) {
    var lists;
    (function (lists) {
        'use strict';
        var planListSevice = (function () {
            function planListSevice($http) {
                this.$http = $http;
            }
            planListSevice.prototype.getAllLists = function () {
                return this.$http.get('/api/lists');
            };
            planListSevice.prototype.getList = function (id) {
                return this.$http.get('/api/list/' + id);
            };
            planListSevice.prototype.addList = function (name) {
                var model = new lists.addPlanListViewModel();
                model.name = name;
                return this.$http.post('api/list/create', model);
            };
            planListSevice.prototype.deleteList = function (listId) {
                return this.$http.delete('/api/list/' + listId);
            };
            planListSevice.prototype.addItem = function (listId, text) {
                var model = new lists.addPlanListItemViewModel();
                model.listId = listId;
                model.text = text;
                return this.$http.post('/api/list/create/item', model);
            };
            planListSevice.prototype.deleteItem = function (itemId) {
                return this.$http.delete('/api/list/item/' + itemId);
            };
            planListSevice.$inject = ['$http'];
            return planListSevice;
        })();
        lists.planListSevice = planListSevice;
        angular.module('zombieApp').service('planListService', planListSevice);
    })(lists = zombieApp.lists || (zombieApp.lists = {}));
})(zombieApp || (zombieApp = {}));
