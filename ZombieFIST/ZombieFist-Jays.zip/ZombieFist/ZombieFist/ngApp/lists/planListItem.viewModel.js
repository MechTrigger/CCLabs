var zombieApp;
(function (zombieApp) {
    var lists;
    (function (lists) {
        // Typescript class that holds our profile info
        var planListItemViewModel = (function () {
            function planListItemViewModel() {
            }
            return planListItemViewModel;
        })();
        lists.planListItemViewModel = planListItemViewModel;
    })(lists = zombieApp.lists || (zombieApp.lists = {}));
})(zombieApp || (zombieApp = {}));
