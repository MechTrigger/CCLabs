﻿//  moved identity logic from controller to service
namespace zombieApp.lists {
    'use strict';


    export interface IPlanListSevice {
        getAllLists(): ng.IHttpPromise<Array<planListViewModel>>; 
        getList(id: number): ng.IHttpPromise<planListViewModel>;
        addItem(listId: number, text: string): ng.IHttpPromise<Object>;
        deleteItem(itemId: number): ng.IHttpPromise<Object>;
        addList(name: string): ng.IHttpPromise<Object>;
        deleteList(listId: number): ng.IHttpPromise<Object>;
    }


    export class planListSevice implements IPlanListSevice {
        static $inject: string[] = ['$http'];


        constructor(private $http: ng.IHttpService) {
        }


        getAllLists(): ng.IHttpPromise<Array<planListViewModel>> {
            return this.$http.get('/api/lists');
        }

        getList(id: number): ng.IHttpPromise<planListViewModel> {
            return this.$http.get('/api/list/' + id);
        }

        addList(name: string): ng.IHttpPromise<Object> {
            var model = new addPlanListViewModel();
            model.name = name;
            return this.$http.post('api/list/create', model);
        }

        deleteList(listId: number): ng.IHttpPromise<Object> {
            return this.$http.delete('/api/list/' + listId);
        }

        addItem(listId: number, text: string): ng.IHttpPromise<Object> {
            var model = new addPlanListItemViewModel();
            model.listId = listId;
            model.text = text;
            return this.$http.post('/api/list/create/item', model);
        }

        deleteItem(itemId: number): ng.IHttpPromise<Object> {
            return this.$http.delete('/api/list/item/' + itemId);
        }
    }

    angular.module('zombieApp').service('planListService', planListSevice);
}