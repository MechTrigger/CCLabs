var zombieApp;
(function (zombieApp) {
    var lists;
    (function (lists) {
        // Typescript class that matches up with the C# class used by Web Api
        var addPlanListItemViewModel = (function () {
            function addPlanListItemViewModel() {
            }
            return addPlanListItemViewModel;
        })();
        lists.addPlanListItemViewModel = addPlanListItemViewModel;
    })(lists = zombieApp.lists || (zombieApp.lists = {}));
})(zombieApp || (zombieApp = {}));
