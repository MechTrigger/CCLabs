﻿namespace zombieApp.lists {

    // Typescript class that holds our profile info
    export class planListItemViewModel {
        id: number;
        text: string;
    }
}