var zombieApp;
(function (zombieApp) {
    var lists;
    (function (lists) {
        // Typescript class that holds our profile info
        var planListViewModel = (function () {
            function planListViewModel() {
            }
            return planListViewModel;
        })();
        lists.planListViewModel = planListViewModel;
    })(lists = zombieApp.lists || (zombieApp.lists = {}));
})(zombieApp || (zombieApp = {}));
