﻿namespace zombieApp.lists {

    // Typescript class that matches up with the C# class used by Web Api
    export class addPlanListViewModel {
        name: string;
    }
}