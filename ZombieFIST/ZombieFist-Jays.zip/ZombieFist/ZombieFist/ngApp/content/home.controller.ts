﻿namespace zombieApp.content {
    
    class homeController {
        static $inject: string[] = [];

        constructor() {
        }
    }

    angular.module('zombieApp').controller('homeController', homeController);
} 