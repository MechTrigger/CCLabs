﻿namespace zombieApp.identity {

    // Typescript class that holds our profile info
    export class userProfileViewModel {
        firstName: string;
        lastName: string;
        email: string;
        isAuthenticated: boolean;
    }
}